#include <time.h>

#ifdef TIME
double getTime();
double timeRDTSC();
#endif